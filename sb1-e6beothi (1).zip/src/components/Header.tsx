import React, { useState } from 'react';
import { Menu, X, ShoppingBag } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-gray-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <ShoppingBag className="w-6 h-6 text-purple-500" />
            <span className="text-xl font-luxury-display font-medium tracking-[0.2em] text-white">PROFITSFR</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#shop" className="text-gray-300 hover:text-white transition-colors duration-200 font-crimson">Shop</a>
            <a href="#about" className="text-gray-300 hover:text-white transition-colors duration-200 font-crimson">About</a>
            <a href="#contact" className="text-gray-300 hover:text-white transition-colors duration-200 font-crimson">Contact</a>
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-300 hover:text-white"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-800/50">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#shop" className="block px-3 py-2 text-gray-300 hover:text-white transition-colors duration-200 font-crimson">Shop</a>
              <a href="#about" className="block px-3 py-2 text-gray-300 hover:text-white transition-colors duration-200 font-crimson">About</a>
              <a href="#contact" className="block px-3 py-2 text-gray-300 hover:text-white transition-colors duration-200 font-crimson">Contact</a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;