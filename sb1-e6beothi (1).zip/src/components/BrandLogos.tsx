import React from 'react';
import { Headphones, Sparkles, Shirt, Star, Watch } from 'lucide-react';

const BrandLogos: React.FC = () => {
  const brands = [
    { name: 'AirPods', icon: Headphones },
    { name: 'Cologne', icon: Sparkles },
    { name: 'Denim Tears', icon: Shirt },
    { name: 'Hellstar', icon: Star },
    { name: 'Luxury Watch', icon: Watch },
  ];

  return (
    <section className="py-20 bg-gray-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-luxury-heading font-medium text-white mb-4">Trusted Vendors</h2>
          <p className="text-gray-400 font-crimson">Premium brands. Verified authenticity.</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center">
          {brands.map((brand, index) => {
            const IconComponent = brand.icon;
            return (
              <div
                key={brand.name}
                className="flex flex-col items-center space-y-4 group cursor-pointer transition-all duration-300 opacity-60 hover:opacity-100"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center group-hover:bg-purple-600/20 transition-all duration-300">
                  <IconComponent className="w-8 h-8 text-gray-400 group-hover:text-purple-400 transition-colors duration-300" />
                </div>
                <span className="text-sm text-gray-500 group-hover:text-gray-300 transition-colors duration-300 font-luxury-heading font-medium">
                  {brand.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default BrandLogos;