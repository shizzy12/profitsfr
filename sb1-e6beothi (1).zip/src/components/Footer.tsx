import React from 'react';
import { Instagram, Twitter, Facebook, ShoppingBag } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-gray-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          {/* Logo */}
          <div className="flex items-center justify-center space-x-2 mb-8">
            <ShoppingBag className="w-8 h-8 text-purple-500" />
            <span className="text-2xl font-luxury-display font-medium tracking-[0.2em] text-white">PROFITSFR</span>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-wrap justify-center space-x-8 mb-8">
            <a href="#shop" className="text-gray-400 hover:text-white transition-colors duration-200 py-2 font-crimson">Shop</a>
            <a href="#about" className="text-gray-400 hover:text-white transition-colors duration-200 py-2 font-crimson">About</a>
            <a href="#terms" className="text-gray-400 hover:text-white transition-colors duration-200 py-2 font-crimson">Terms</a>
            <a href="#contact" className="text-gray-400 hover:text-white transition-colors duration-200 py-2 font-crimson">Contact</a>
          </nav>

          {/* Social Icons */}
          <div className="flex justify-center space-x-6 mb-8">
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-all duration-300 hover:scale-110 p-2">
              <Instagram className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-all duration-300 hover:scale-110 p-2">
              <Twitter className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-all duration-300 hover:scale-110 p-2">
              <Facebook className="w-6 h-6" />
            </a>
          </div>

          {/* Copyright */}
          <div className="border-t border-gray-800/50 pt-8">
            <p className="text-gray-500 text-sm font-crimson">
              © 2025 Profitsfr. All rights reserved. Luxury redefined, authenticity guaranteed.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;