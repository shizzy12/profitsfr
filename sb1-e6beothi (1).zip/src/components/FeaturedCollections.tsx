import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const FeaturedCollections: React.FC = () => {
  const collections = [
    {
      name: 'AirPods Pro',
      tagline: 'Premium Audio Experience',
      image: 'https://images.pexels.com/photos/8534088/pexels-photo-8534088.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Tech',
      link: '/airpods-pro'
    },
    {
      name: 'Luxury Fragrances',
      tagline: 'Signature Scents Collection',
      image: 'https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Fragrance',
      link: '#'
    },
    {
      name: 'Denim Tears',
      tagline: 'Exclusive Streetwear Drops',
      image: 'https://images.pexels.com/photos/1124460/pexels-photo-1124460.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Fashion',
      link: '#'
    },
    {
      name: 'Luxury Timepieces',
      tagline: 'Swiss Craftsmanship',
      image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      category: 'Watches',
      link: '#'
    }
  ];

  return (
    <div>
      <div className="text-center mb-12">
        <h2 className="text-2xl sm:text-3xl font-luxury-heading font-medium text-white mb-4 tracking-wide">
          Featured Collections
        </h2>
        <p className="text-base font-crimson text-gray-400 max-w-xl mx-auto leading-relaxed">
          Discover our handpicked selection of luxury items from premium vendors
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {collections.map((collection, index) => (
          <Link
            key={collection.name}
            to={collection.link}
            className="group bg-black/50 backdrop-blur-sm border border-gray-800/50 overflow-hidden hover:border-purple-500/50 transition-all duration-500 cursor-pointer block"
            style={{ animationDelay: `${index * 150}ms` }}
          >
            <div className="aspect-w-16 aspect-h-12 relative overflow-hidden">
              <img
                src={collection.image}
                alt={collection.name}
                className="w-full h-40 object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            </div>
            
            <div className="p-5">
              <span className="text-xs text-purple-400 font-luxury-heading font-medium tracking-[0.15em] uppercase">
                {collection.category}
              </span>
              <h3 className="text-lg font-luxury-heading font-medium text-white mt-2 mb-2 group-hover:text-purple-300 transition-colors duration-300">
                {collection.name}
              </h3>
              <p className="text-gray-400 text-sm font-crimson mb-4 leading-relaxed">
                {collection.tagline}
              </p>
              
              <div className="flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors duration-300 group-hover:translate-x-1 transform transition-transform">
                <span className="text-sm font-luxury-heading font-medium">Explore</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default FeaturedCollections;