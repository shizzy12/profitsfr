import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-32 bg-black">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-fade-in">
          <h2 className="text-4xl sm:text-5xl font-luxury-heading font-medium text-white mb-8 tracking-wide">
            About Profitsfr
          </h2>
          
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-purple-300 mx-auto mb-12"></div>
          
          <p className="text-xl font-crimson text-gray-300 leading-relaxed mb-8">
            Curated drops from top-tier brands, meticulously verified for authenticity. 
            We bridge the gap between luxury and accessibility, bringing you exclusive 
            pieces from the world's most coveted collections.
          </p>
          
          <p className="text-lg font-crimson text-gray-400 leading-relaxed">
            Every item in our collection tells a story of craftsmanship, exclusivity, 
            and timeless appeal. From limited edition streetwear to luxury timepieces, 
            we ensure each piece meets our exacting standards.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;