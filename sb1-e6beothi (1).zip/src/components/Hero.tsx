import React from 'react';
import FeaturedCollections from './FeaturedCollections';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-black overflow-hidden">
      {/* Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-black"></div>
      
      {/* Subtle animated orb */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-pulse"></div>

      {/* Spline 3D Animation Background - Optimized for Mobile Visibility */}
      <div className="absolute top-16 sm:top-20 md:top-24 left-0 right-0 bottom-0 z-0 opacity-40">
        <spline-viewer 
          url="https://prod.spline.design/LhOsu4xcawiRvOan/scene.splinecode"
          style={{
            width: '100%',
            height: '100%',
            background: 'transparent',
            filter: 'hue-rotate(270deg) saturate(1.5) brightness(0.8)',
            mixBlendMode: 'screen',
            border: 'none',
            outline: 'none',
            margin: '0',
            padding: '0'
          }}
          loading-bg-color="transparent"
          events-target="global"
        />
      </div>

      <div className="relative z-10 px-4 sm:px-6 lg:px-8">
        {/* Main hero content - compact mobile spacing */}
        <div className="pt-20 sm:pt-24 pb-6 sm:pb-8 md:pb-16 text-center">
          <div className="animate-fade-in-up">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-luxury-display font-medium text-white mb-3 sm:mb-4 tracking-[0.15em]">
              PROFITSFR
            </h1>
            
            {/* Enhanced bouncing animated gradient bar with glow - responsive width */}
            <div className="profitsfr-underline-container w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg h-1 mx-auto mb-4 sm:mb-6 relative">
              <div className="w-full h-full bg-gradient-to-r from-purple-500 to-purple-300 animate-bouncing-slider-full shadow-glow-purple"></div>
            </div>
            
            <p className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-luxury-heading font-light text-gray-300 mb-3 sm:mb-4 tracking-[0.1em]">
              RESALE REDEFINED
            </p>
            
            <p className="text-sm sm:text-base font-crimson text-gray-400 mb-4 sm:mb-6 md:mb-8 max-w-xl mx-auto leading-relaxed px-4">
              Premium drops. Genuine collections. Curated for the discerning collector.
            </p>
            
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 sm:px-8 md:px-10 py-2.5 sm:py-3 text-sm sm:text-base font-luxury-heading font-medium tracking-[0.1em] transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/25 mb-6 sm:mb-8 md:mb-12">
              SHOP NOW
            </button>
          </div>
        </div>

        {/* Featured Collections - tighter mobile spacing */}
        <div className="max-w-7xl mx-auto pb-12 sm:pb-16 md:pb-20">
          <FeaturedCollections />
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-4 sm:bottom-6 md:bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-4 h-6 sm:w-5 sm:h-8 md:w-6 md:h-10 border-2 border-gray-600 rounded-full p-1">
            <div className="w-0.5 h-1.5 sm:w-1 sm:h-2 md:h-3 bg-gray-600 rounded-full mx-auto animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;