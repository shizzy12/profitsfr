import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import BrandLogos from './components/BrandLogos';
import About from './components/About';
import HowItWorks from './components/HowItWorks';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';
import CursorGlow from './components/CursorGlow';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <CursorGlow />
      <Header />
      <Hero />
      <BrandLogos />
      <About />
      <HowItWorks />
      <Newsletter />
      <Footer />
    </div>
  );
}

export default App;