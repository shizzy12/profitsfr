import React, { useState } from 'react';
import { Mail } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log('Newsletter signup:', email);
    setEmail('');
  };

  return (
    <section className="py-32 bg-gray-900/50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-black/50 backdrop-blur-sm border border-gray-800/50 p-12 lg:p-16">
          <div className="mb-8">
            <Mail className="w-16 h-16 text-purple-500 mx-auto mb-6" />
            <h2 className="text-4xl sm:text-5xl font-luxury-heading font-medium text-white mb-6 tracking-wide">
              Stay Updated
            </h2>
            <p className="text-xl font-crimson text-gray-400 leading-relaxed">
              Get early access to exclusive drops and limited collections before they sell out
            </p>
          </div>

          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="flex-1 px-6 py-4 bg-gray-800/50 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors duration-300 font-crimson"
                required
              />
              <button
                type="submit"
                className="px-8 py-4 bg-purple-600 hover:bg-purple-700 text-white font-luxury-heading font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/25"
              >
                GET EARLY ACCESS
              </button>
            </div>
          </form>

          <p className="text-sm text-gray-500 font-crimson mt-6">
            Join 10,000+ collectors who trust Profitsfr for authentic luxury items
          </p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;