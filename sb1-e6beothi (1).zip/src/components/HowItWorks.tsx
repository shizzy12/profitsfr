import React from 'react';
import { Search, Shield, Truck } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '1',
      title: 'Discover Drops',
      description: 'Browse our curated collection of premium items from verified vendors',
      icon: Search
    },
    {
      step: '2',
      title: 'Secure Checkout',
      description: 'Complete your purchase with confidence using our encrypted payment system',
      icon: Shield
    },
    {
      step: '3',
      title: 'Fast Delivery',
      description: 'Receive your authentic luxury items with expedited, tracked shipping',
      icon: Truck
    }
  ];

  return (
    <section className="py-32 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl sm:text-5xl font-luxury-heading font-medium text-white mb-6 tracking-wide">
            How It Works
          </h2>
          <p className="text-xl font-crimson text-gray-400 max-w-2xl mx-auto">
            Three simple steps to access the world's most exclusive collections
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {steps.map((step, index) => {
            const IconComponent = step.icon;
            return (
              <div
                key={step.step}
                className="text-center group"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="relative mb-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                    <IconComponent className="w-10 h-10 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-luxury-heading font-bold text-sm">
                    {step.step}
                  </div>
                </div>
                
                <h3 className="text-2xl font-luxury-heading font-medium text-white mb-4 group-hover:text-purple-300 transition-colors duration-300">
                  {step.title}
                </h3>
                
                <p className="text-gray-400 font-crimson leading-relaxed max-w-xs mx-auto">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;