import React, { useEffect, useRef, useCallback } from 'react';

const CursorGlow: React.FC = () => {
  const glowRef = useRef<HTMLDivElement>(null);
  const isClickingRef = useRef(false);
  const isTouchingRef = useRef(false);
  const isVisibleRef = useRef(false);
  const animationFrameRef = useRef<number>();

  const updateGlowStyle = useCallback((x: number, y: number) => {
    if (!glowRef.current) return;

    const isActive = isClickingRef.current || isTouchingRef.current;
    const glowSize = isActive ? 140 : 120;
    const glowOpacity = isActive ? 0.4 : 0.25;

    // Use transform for hardware acceleration and immediate positioning
    glowRef.current.style.transform = `translate3d(${x - glowSize / 2}px, ${y - glowSize / 2}px, 0) scale(${isVisibleRef.current ? 1 : 0})`;
    glowRef.current.style.width = `${glowSize}px`;
    glowRef.current.style.height = `${glowSize}px`;
    glowRef.current.style.background = `radial-gradient(circle, rgba(139, 92, 246, ${glowOpacity}) 0%, rgba(124, 58, 237, ${glowOpacity * 0.7}) 25%, rgba(109, 40, 217, ${glowOpacity * 0.4}) 50%, transparent 70%)`;
    glowRef.current.style.opacity = isVisibleRef.current ? '1' : '0';
  }, []);

  // Mouse events for desktop
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      
      animationFrameRef.current = requestAnimationFrame(() => {
        updateGlowStyle(e.clientX, e.clientY);
      });
      
      if (!isVisibleRef.current) {
        isVisibleRef.current = true;
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      isClickingRef.current = true;
      updateGlowStyle(e.clientX, e.clientY);
    };

    const handleMouseUp = (e: MouseEvent) => {
      isClickingRef.current = false;
      updateGlowStyle(e.clientX, e.clientY);
    };

    const handleMouseLeave = () => {
      isVisibleRef.current = false;
      if (glowRef.current) {
        glowRef.current.style.opacity = '0';
        glowRef.current.style.transform = glowRef.current.style.transform.replace(/scale\([^)]*\)/, 'scale(0)');
      }
    };

    const handleMouseEnter = (e: MouseEvent) => {
      isVisibleRef.current = true;
      updateGlowStyle(e.clientX, e.clientY);
    };

    // Only add mouse events on non-touch devices
    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    
    if (!isTouch) {
      document.addEventListener('mousemove', handleMouseMove, { passive: true });
      document.addEventListener('mousedown', handleMouseDown, { passive: true });
      document.addEventListener('mouseup', handleMouseUp, { passive: true });
      document.addEventListener('mouseleave', handleMouseLeave, { passive: true });
      document.addEventListener('mouseenter', handleMouseEnter, { passive: true });
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [updateGlowStyle]);

  // Touch events for mobile
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0];
      if (touch) {
        isTouchingRef.current = true;
        isVisibleRef.current = true;
        updateGlowStyle(touch.clientX, touch.clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      const touch = e.touches[0];
      if (touch) {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
        
        animationFrameRef.current = requestAnimationFrame(() => {
          updateGlowStyle(touch.clientX, touch.clientY);
        });
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      isTouchingRef.current = false;
      const touch = e.changedTouches[0];
      if (touch) {
        updateGlowStyle(touch.clientX, touch.clientY);
      }
      
      // Fade out after touch release
      setTimeout(() => {
        isVisibleRef.current = false;
        if (glowRef.current) {
          glowRef.current.style.opacity = '0';
          glowRef.current.style.transform = glowRef.current.style.transform.replace(/scale\([^)]*\)/, 'scale(0)');
        }
      }, 150);
    };

    document.addEventListener('touchstart', handleTouchStart, { passive: true });
    document.addEventListener('touchmove', handleTouchMove, { passive: true });
    document.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [updateGlowStyle]);

  return (
    <div
      ref={glowRef}
      className="cursor-glow fixed pointer-events-none z-50 mix-blend-screen rounded-full"
      style={{
        left: 0,
        top: 0,
        width: '120px',
        height: '120px',
        background: 'radial-gradient(circle, rgba(139, 92, 246, 0.25) 0%, rgba(124, 58, 237, 0.175) 25%, rgba(109, 40, 217, 0.1) 50%, transparent 70%)',
        transform: 'translate3d(-60px, -60px, 0) scale(0)',
        opacity: 0,
        transition: 'opacity 300ms cubic-bezier(0.4, 0, 0.2, 1), width 300ms cubic-bezier(0.4, 0, 0.2, 1), height 300ms cubic-bezier(0.4, 0, 0.2, 1)',
        willChange: 'transform, opacity, width, height',
      }}
    />
  );
};

export default CursorGlow;