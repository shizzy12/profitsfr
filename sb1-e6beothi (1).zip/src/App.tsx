import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AirPodsPage from './pages/AirPodsPage';
import CursorGlow from './components/CursorGlow';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <CursorGlow />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/airpods-pro" element={<AirPodsPage />} />
      </Routes>
    </div>
  );
}

export default App;