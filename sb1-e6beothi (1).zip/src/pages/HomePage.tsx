import React from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import BrandLogos from '../components/BrandLogos';
import About from '../components/About';
import HowItWorks from '../components/HowItWorks';
import Newsletter from '../components/Newsletter';
import Footer from '../components/Footer';

const HomePage: React.FC = () => {
  return (
    <>
      <Header />
      <Hero />
      <BrandLogos />
      <About />
      <HowItWorks />
      <Newsletter />
      <Footer />
    </>
  );
};

export default HomePage;