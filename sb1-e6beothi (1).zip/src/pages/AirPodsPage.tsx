import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Star, Shield, Truck, Heart, ShoppingCart, Headphones } from 'lucide-react';

const AirPodsPage: React.FC = () => {
  const [selectedVariant, setSelectedVariant] = useState(0);
  const [quantity, setQuantity] = useState(1);

  const variants = [
    {
      id: 1,
      name: 'AirPods Pro (3rd Generation)',
      price: 69.99,
      originalPrice: 249.99,
      image: 'https://images.pexels.com/photos/8534088/pexels-photo-8534088.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      condition: 'Like New',
      authenticity: 'Verified Authentic'
    },
    {
      id: 2,
      name: 'AirPods Pro (2nd Generation)',
      price: 59.99,
      originalPrice: 199.99,
      image: 'https://images.pexels.com/photos/7048047/pexels-photo-7048047.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      condition: 'Excellent',
      authenticity: 'Verified Authentic'
    }
  ];

  const reviews = [
    {
      id: 1,
      name: 'Marcus Chen',
      rating: 5,
      date: '2 days ago',
      comment: 'Absolutely perfect condition! Sound quality is incredible and they arrived exactly as described. Profitsfr delivers on their promise of authenticity.',
      verified: true
    },
    {
      id: 2,
      name: 'Sarah Williams',
      rating: 5,
      date: '1 week ago',
      comment: 'Amazing deal for genuine AirPods Pro. Fast shipping and excellent customer service. Will definitely shop here again!',
      verified: true
    },
    {
      id: 3,
      name: 'David Rodriguez',
      rating: 5,
      date: '2 weeks ago',
      comment: 'These are the real deal! Perfect for my daily commute. The noise cancellation works flawlessly. Great price too.',
      verified: true
    },
    {
      id: 4,
      name: 'Emma Thompson',
      rating: 4,
      date: '3 weeks ago',
      comment: 'Very satisfied with my purchase. Arrived quickly and in pristine condition. Highly recommend Profitsfr for luxury tech.',
      verified: true
    }
  ];

  const features = [
    'Active Noise Cancellation',
    'Transparency Mode',
    'Spatial Audio with Dynamic Head Tracking',
    'Up to 6 hours listening time',
    'MagSafe Charging Case',
    'Sweat and Water Resistant (IPX4)'
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors duration-200">
              <ArrowLeft className="w-5 h-5" />
              <span className="font-crimson">Back to Home</span>
            </Link>
            
            <div className="flex items-center space-x-2">
              <Headphones className="w-6 h-6 text-purple-500" />
              <span className="text-xl font-luxury-display font-medium tracking-[0.2em] text-white">PROFITSFR</span>
            </div>
          </div>
        </div>
      </header>

      <div className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            {/* Product Images */}
            <div className="space-y-6">
              <div className="aspect-square bg-gray-900/50 rounded-lg overflow-hidden border border-gray-800/50">
                <img
                  src={variants[selectedVariant].image}
                  alt={variants[selectedVariant].name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {variants.map((variant, index) => (
                  <button
                    key={variant.id}
                    onClick={() => setSelectedVariant(index)}
                    className={`aspect-square bg-gray-900/50 rounded-lg overflow-hidden border-2 transition-all duration-300 ${
                      selectedVariant === index ? 'border-purple-500' : 'border-gray-800/50 hover:border-gray-700'
                    }`}
                  >
                    <img
                      src={variant.image}
                      alt={variant.name}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-8">
              <div>
                <h1 className="text-3xl sm:text-4xl font-luxury-heading font-medium text-white mb-4">
                  {variants[selectedVariant].name}
                </h1>
                
                <div className="flex items-center space-x-4 mb-6">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-gray-400 ml-2 font-crimson">(127 reviews)</span>
                  </div>
                </div>

                <div className="flex items-center space-x-4 mb-6">
                  <span className="text-3xl font-luxury-heading font-medium text-white">
                    ${variants[selectedVariant].price}
                  </span>
                  <span className="text-xl text-gray-500 line-through font-crimson">
                    ${variants[selectedVariant].originalPrice}
                  </span>
                  <span className="bg-green-600 text-white px-3 py-1 text-sm font-luxury-heading font-medium">
                    {Math.round((1 - variants[selectedVariant].price / variants[selectedVariant].originalPrice) * 100)}% OFF
                  </span>
                </div>

                <div className="flex items-center space-x-6 mb-8">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-green-500" />
                    <span className="text-green-500 font-crimson">{variants[selectedVariant].authenticity}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-3 h-3 bg-green-500 rounded-full"></span>
                    <span className="text-gray-300 font-crimson">{variants[selectedVariant].condition}</span>
                  </div>
                </div>
              </div>

              {/* Quantity and Add to Cart */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <label className="text-gray-300 font-crimson">Quantity:</label>
                  <div className="flex items-center border border-gray-700 rounded">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-gray-300 hover:text-white transition-colors"
                    >
                      -
                    </button>
                    <span className="px-4 py-2 text-white font-crimson">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 text-gray-300 hover:text-white transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-4 px-6 font-luxury-heading font-medium tracking-[0.1em] transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/25 flex items-center justify-center space-x-2">
                    <ShoppingCart className="w-5 h-5" />
                    <span>ADD TO CART</span>
                  </button>
                  <button className="p-4 border border-gray-700 hover:border-purple-500 text-gray-300 hover:text-purple-400 transition-all duration-300">
                    <Heart className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {/* Features */}
              <div>
                <h3 className="text-xl font-luxury-heading font-medium text-white mb-4">Key Features</h3>
                <ul className="space-y-2">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-gray-300 font-crimson">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Shipping Info */}
              <div className="bg-gray-900/50 border border-gray-800/50 p-6 rounded-lg">
                <div className="flex items-center space-x-3 mb-4">
                  <Truck className="w-6 h-6 text-purple-500" />
                  <h3 className="text-lg font-luxury-heading font-medium text-white">Shipping & Returns</h3>
                </div>
                <ul className="space-y-2 text-gray-300 font-crimson">
                  <li>• Free expedited shipping on orders over $50</li>
                  <li>• 30-day return policy</li>
                  <li>• Authenticity guarantee</li>
                  <li>• Secure packaging with tracking</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Reviews Section */}
          <div className="border-t border-gray-800/50 pt-16">
            <div className="mb-12">
              <h2 className="text-3xl font-luxury-heading font-medium text-white mb-6">Customer Reviews</h2>
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span className="text-2xl font-luxury-heading font-medium text-white">4.9</span>
                </div>
                <span className="text-gray-400 font-crimson">Based on 127 reviews</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {reviews.map((review) => (
                <div key={review.id} className="bg-gray-900/50 border border-gray-800/50 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-luxury-heading font-medium">
                          {review.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-white font-luxury-heading font-medium">{review.name}</h4>
                        {review.verified && (
                          <span className="text-green-500 text-sm font-crimson">Verified Purchase</span>
                        )}
                      </div>
                    </div>
                    <span className="text-gray-400 text-sm font-crimson">{review.date}</span>
                  </div>
                  
                  <div className="flex items-center space-x-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                  
                  <p className="text-gray-300 font-crimson leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AirPodsPage;