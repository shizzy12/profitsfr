/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'luxury-heading': ['Cormorant Garamond', 'Georgia', 'Times New Roman', 'serif'],
        'luxury-display': ['Cinzel', 'Georgia', 'Times New Roman', 'serif'],
        'crimson': ['Crimson Text', 'Georgia', 'Times New Roman', 'serif'],
      },
    },
  },
  plugins: [],
};